<body>
    <div class="background">
        <div class="navbar">
            <img alt="logo" src="/image/SweetD'cups.png" class="logo" />
            <ul>
                <li><a href="/" class="active"> Home </a></li>
                <li><a href="/myhome/menu"> Menu </a> </li>
                <li><a href="/myhome/location"> Location </a></li>
                <li><a href="/myhome/about"> About Us </a></li>
                <li><a href="/myhome/testimony">Testimony</a></li>
            </ul>
        </div>