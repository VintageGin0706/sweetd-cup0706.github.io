<div class="bg">
    <div>
        <p class="testi-tt">
            Testimony
        </p>
    </div>

    <div>
        <p class="testi-nama">
            Padmavati Darmaputri
        </p>
    </div>

    <div>
        <p class="testi-content">
            Suka dengan Ocean Beach karena gradasinya yang unik. Selain itu rasanya juga enak cocok buat kaum remaja yang suka foto-foto minuman asthetic.
        </p>
    </div>

    <div>
       <img src="/image/vava.jpg" alt="vava" class="vava">
    </div>

    <div>
        <img src="/image/star.png" alt="star" class="star">
    </div>

    <div>
        <p class="testi-nama2">
            Christopher Kevin
        </p>
    </div>

    <div>
        <p class="testi-content2">
            Lebih suka variant Lemonade jujur karena lebih enak selain itu lemon nya seger.Wajib coba.Soso ne ga nyoba lemonade.ck..ck..ck
        </p>
    </div>

    <div>
        <img src="/image/kevin.jpeg" alt="kevin" class="kevin" >
    </div>

    <div>
        <img src="/image/star.png" alt="star" class="star2">
    </div>

    <div>
        <p class="testi-nama3">
        Dionisius Reinaldo
        </p>
    </div>

    <div>
        <p class="testi-content3">
        Kamu nanyaaa...Kesukaanku apaa? Aku suka minum lemonade selain enak,cocok buat kantong mahasiswa.Dah itu ajaa...
        </p>
    </div>

    <div>
        <img src="/image/aldo.jpg" alt="aldo" class="aldo">
    </div>

    <div>
        <img src="/image/star.png" alt="star" class="star3">
    </div>
</div>
