
    <div>
      <h1 class="about">
        About Us
    </div>

    <div>
      <p class="about-content">
        Sweet D'Cup merupakan brand asal Indonesia 
        yang berdiri sejak 2022,didirikan oleh 4 Founder Utama.
        Menyajikan minuman berbahan dasar lemon,dengan rasa yang
        bervariasi.
      </p>
    </div>

    <div>
      <img src="/image/sweetdicupawal.png" alt="sweet-logo" class="sweet">
    </div>

    <div>
      <p class="about-content2">
        Menggunakan Bahan-bahan berkualitas dalam pembuatan minumannya.Selain itu,
        Sweet D'Cups berkomitmen menciptakan minuman yang enak sekaligus bisa dinikmati masyarakat luas dengan harga yang terjangkau
      </p>
    </div>

    <div>
      <img src="/image/about.png" alt="content" class="jpeg">
    </div>

  

    <div>
      <h1 class="founder">
        Founder Sweet D'Cup
      </h1>
    </div>

    <div>
      <img src="/image/jojo.jpeg" alt="jojo" class="jojo">
    </div>

    <div>
      <p class="jabatan">
        CEO
      </p>
    </div>

    <div>
      <p class="nama">
        Jhonatan Laurensius Tjahjadi
      </p>
    </div>

  <div class="cont-img">
    <div>
      <p>
        <img src="/image/My pict.jpeg" alt="dewa" class="dewa">
      </p>
    </div>

    <div>
      <p class="jabatan2">
        CTO
      </p>
    </div>

    <div>
      <p class="nama2">
        Theofilus Dewa
      </p>
    </div>
  </div>
    
  <div class="cont-img2">
    <div>
      <p>
        <img src="/image/dita.jpg" alt="dita" class="dita">
      </p>
    </div>

    <div>
      <p class="jabatan3">
        CFO
      </p>
    </div>

    <div>
      <p class="nama3">
        Dita Anggelia
      </p>
    </div>
  </div>

  <div class="cont-img3">
    <div>
      <p>
        <img src="/image/nathan.jpg" alt="nathan" class="nathan">
      </p>
    </div>

    <div>
      <p class="jabatan4">
        CTO
      </p>
    </div>

    <div>
      <p class="nama4">
        Nathanael Christian
      </p>
    </div>
  </div>


  
  