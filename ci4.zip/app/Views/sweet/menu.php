<?= $this->extend('/template/template'); ?>



<?= $this->section('content'); ?>
<div>
    <p class="oc">
        Our Menu
    </p>
</div>

<div>
    <img src="/image/ocean.jpg" alt="ocean" class="ocean">
</div>

<div>
    <p class="oc2">
        Ocean Beach
    </p>
</div>

<div>
    <p class="oc3">
        Taste the soda with blue syrup and lemon
    </p>
</div>

<div>
    <img src="/image/lemonade.jpg" alt="lemonade" class="lemon">
</div>

<div>
    <p class="oc2">
        Lemonade
    </p>
</div>

<div>
    <p class="oc4">
        Feel the Fresh of lemon 
    </p>
</div>
<?= $this->endSection('content'); ?>