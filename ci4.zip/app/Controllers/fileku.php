<?php

namespace App\Controllers;

class fileku extends BaseController
{
    public function index()
    {
        return view('sweet/us');
    }

    
    public function we()
    {
        return view ('sweet/we');
    }

}
